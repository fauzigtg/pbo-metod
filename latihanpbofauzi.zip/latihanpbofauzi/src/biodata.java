/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohammad__Fauzi
 */
public class biodata {
    public void infoNama() {
        System.out.println("Nama : MOHAMMAD FAUZI"); 
    }
    
    public void infoKelas() {
        System.out.println("Kelas : XI RPL 1");
    }
    
    public void infoAbsen() {
        System.out.println("No.absen : 27");
    }
    
    public void infoTTL() {
        System.out.println("TTL : Pasuruan 19 mei 2004");
    }
    
    public void infoAlamat() {
        System.out.println("Alamat : Desa ngembal Kec.Tutur");
    }
    public void infoHobi() {
        System.out.println("Hobi : Mencintai Semua Wanita");
    }
}
